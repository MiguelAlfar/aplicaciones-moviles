Extensiones en Uso <br>

Ionic <br>
Ionic Snippets <br>
Ionic Extension Pack <br>
Prettier <br>
Brackets Pair Color DLW <br>
One Dark <br>
Material Icon <br>
HTML CSS Support <br>
Auto Close tag <br>
Auto Rename Tag <br>
Lanzamiento APK desde IONIC

ionic cap add android : agrega la plataforma android a las configuracion de distribucion de nuestro aplicativo ,<br> para que sea considerado al momento de sincronizar y actualizar uso de librerias o plugins 

ionic cap sync : Sincroniza librerias plugins y modificaciones con las plataformas indicadas de nuestro proyecto ionic

ionic cap build android : genera la compilacion del codigo y la integracion con android , <br> indicando al aplicativo que debe ser compilado en android studio

Para obtener el APK debemos ingresar al apartado de opcion de :
Build -> Generate Signed App Bundle/APK -> configurar creacion de keyStore y asignar firma <br>
Deben generar variante release como APK final y luego finalizar la creacion
